// BIENVENIDO
Bienvenido a la versión para imprimir de la Guía de Regalos de la FSF. La versión completa la puedes encontrar en https://www.fsf.org/givingguide/, además consejos para organizar un evento de Entrega de la Guía de Regalos los puedes encontrar en are at https://www.fsf.org/givingguide/giving-guide-giveaway-primer.

// PARA IMPRIMIR
Las dos páginas están diseñadas para imprimirse en lados opuestos de la misma hoja. Ésta esta diseñada para un tamaño de papel tipo carta (8.5 x 11 pulgadas).

Antes de imprimir, quizás quieras usar un programa de manipulación de PDFs, como pdfmod, para combinar los dos PDFs en uno sólo, un archivo de dos páginas, pero también está bien imprimir uno sólo en una cara., y después mete las hojas de nuevo en la impresora dadas la vuelta.

Si no lo haces así, siempre puedes imprimir las dos páginas en hojas separadas y graparlas juntas.

// PARA EDITAR
Primero instala las fuentes incluidas en tu equipo (o abre un editor de texto para comprobar que ya las tienes). Después abre los archivos SVG de cada página del directorio "sources". Recomendamos utilizar inkscape para esto. Inkscape puede guardar los acrchivos en PDF cuando hayas terminado, usando Archivo->Guardar una copia.

// PARA TRADUCIR O REDIMENSIONAR
¡Aceptamos las traducciones y redimensionamientos a otros tamaños que hagas! Sin embargo, solicitamos que los traductores a encontrar al menos otra persona que lea inglés para comparar el documento original y el traducido. La FSF pone mucha cuidado en la redacción y es importante para nosotros que se preserve el significado.

Para mantener todo sencillo de utilizar, por favor completa las traducciones/redimensionamientos incluyendo las fuentes, todos los archivos SVG y PDFs, y también el archivo README, guardado en la misma estructura que la versión original en inglés. ¡Puntos extras si traduces el archivo README! Manda tu trabajo finalizado comprimido en ZIP a campaigns@fsf.org.

¡Esperamos disfrutaras usar la Guía de Regalos!
